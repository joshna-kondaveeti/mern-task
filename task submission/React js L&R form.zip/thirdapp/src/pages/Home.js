const Home = () => {
	return (
		<p style={{color:'deeppink'}}>
		All Penguins have a big head an a short and thick neck. Their body are streamlined, with a short tail. Penguins have heavy bones, which allows them to stay in the water. Penguins dive into they water and 'fly' underwater at great speed. Penguins have a light colour skin on their belly, but a darker colour skin on their back, which helps them camouflage them underwater. When they are swimming, the dark colour is on the top, and the light colour is on the bottom. Because the dark colour is on top, it is hard for other animals that are above the penguin to see the penguin.
		</p>
	)
};

export default Home;


